var data = [
	{
		name:"美味汉堡",
		detailData:[
			{img:"/img/ele.png",subname:"汉堡1"},
			{subname:"汉堡2"},
			{subname:"汉堡3"},
			{subname:"汉堡4"}
		]
	},
	{
		name:"美味薯条",
		detailData:[
			{subname:"薯条1"},
			{subname:"薯条2"},
			{subname:"薯条3"},
			{subname:"薯条4"}
		]
	}
]

module.exports = {
	data: data
}